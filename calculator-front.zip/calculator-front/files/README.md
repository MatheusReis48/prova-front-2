# Calculator HTML - CSS - JAVASCRIPT

## Description

This is a simple calculator made with HTML, CSS and Javascript. It has the basic operations of a calculator, such as addition, subtraction, multiplication and division.
